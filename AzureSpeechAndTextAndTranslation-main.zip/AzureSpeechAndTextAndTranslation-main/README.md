# AzureSpeechAndText
Azure Cognitive Services using Speech and Text capabilities
